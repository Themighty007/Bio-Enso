import React from "react";
import { SylvaHero } from "@designcodeio/threeui";

export default function App() {
  return (
    <div style={{ width: "100vw", height: "100vh", overflow: "hidden", background: "#383b34" }}>
      <SylvaHero
        primaryColor="#FFFFFF"
        headingSize={63}
        bodySize={16.5}
        headingWeight="300"
        bodyWeight="300"
      />
    </div>
  );
}

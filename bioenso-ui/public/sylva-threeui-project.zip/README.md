# Sylva Hero — ThreeUI 3D Living World

An exact, production-ready copy of [threeui.com/hero/sylva](https://threeui.com/hero/sylva) built with React, Vite, and [`@designcodeio/threeui`](https://www.npmjs.com/package/@designcodeio/threeui).

![Sylva Hero](https://threeui.com/hero/sylva)

## ✨ Overview

**Sylva** is an interactive Three.js landscape study and hero landing page originally created by Meng To for ThreeUI. It features:

- **Procedural 3D Organics**: Interactive moss-covered root winding through a rich forest canvas with flowering branches and ambient lighting.
- **Dynamic Physics & Particles**: Drifting cherry & apple blossom petals, pollen motes, and interactive butterfly physics that react to mouse hover and touch drag.
- **Liquid-Metal & Tactile UI**: Interactive top dock navigation, liquid metal CTA buttons, mask reveal effects, and tactile knobs.
- **Lexend Typography**: Variable geometric typography tuned specifically for high-contrast dark forest backdrops with fluid viewport clamp sizing.
- **Live Reactive Parameters**: Control primary color highlights, font stacks, heading sizes, body sizes, and font weights seamlessly.

---

## 🚀 Quick Start

### 1. Install Dependencies

```bash
npm install
```

### 2. Run the Development Server

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) to view the application.

### 3. Build for Production

```bash
npm run build
```

Preview the production build locally:

```bash
npm run preview
```

---

## 📦 Project Scaffold

```text
├── index.html                           # Entry HTML with Lexend font and metadata
├── package.json                         # Project dependencies and scripts
├── vite.config.js                       # Vite configuration
├── README.md                            # Documentation and deployment guide
├── public/
│   └── landing-pages/
│       ├── inner-green-3d.html          # Core Sylva 3D scene & stage HTML
│       └── inner-green-assets/          # Lexend font, textures, and three.js
│           ├── lexend-latin.woff2
│           ├── card-ethos.jpg
│           ├── card-ecostove.jpg
│           └── three.min.js
└── src/
    ├── App.jsx                          # Main SylvaHero component integration
    ├── App.tsx                          # Full interactive hero with live controls & zip export
    ├── main.tsx                         # React 19 entry point
    └── index.css                        # Tailwind CSS v4 & @designcodeio/threeui styles
```

---

## 🛠 Usage in React

Import and render `SylvaHero` from `@designcodeio/threeui` with the specified parameters:

```jsx
import React from "react";
import { SylvaHero } from "@designcodeio/threeui";

export default function App() {
  return (
    <SylvaHero
      primaryColor="#FFFFFF"
      headingSize={63}
      bodySize={16.5}
      headingWeight="300"
      bodyWeight="300"
    />
  );
}
```

### Component Props

| Prop | Type | Default | Description |
| :--- | :--- | :--- | :--- |
| `primaryColor` | `string` | `"#FFFFFF"` | Color used for text headlines and active accent glows |
| `headingSize` | `number` | `63` | Font size multiplier for title headlines (range: 40–92) |
| `bodySize` | `number` | `16.5` | Font size multiplier for body and subheadings (range: 12–24) |
| `headingWeight`| `string` | `"300"` | Font weight for headings (`"200"`, `"300"`, `"400"`, `"500"`, `"600"`) |
| `bodyWeight` | `string` | `"300"` | Font weight for body copy (`"200"`, `"300"`, `"400"`, `"500"`) |
| `headingFont` | `string` | `"lexend"` | Heading font family (`"lexend"`, `"instrument-serif"`, `"newsreader"`, `"geist"`) |
| `bodyFont` | `string` | `"lexend"` | Body font family (`"lexend"`, `"geist"`, `"newsreader"`, `"instrument-serif"`) |

---

## 🌐 Deployment Instructions

### Vercel

1. Push your repository to GitHub / GitLab.
2. Import the project into [Vercel](https://vercel.com).
3. The build settings are auto-detected (`npm run build`, output directory `dist`).
4. Click **Deploy**.

### Netlify

1. Connect your repository to [Netlify](https://netlify.com).
2. Set Build command: `npm run build`
3. Set Publish directory: `dist`
4. Click **Deploy Site**.

### Cloudflare Pages

1. Go to Workers & Pages > Create application > Pages.
2. Connect your Git repository.
3. Select the **Vite** preset.
4. Output directory: `dist`
5. Click **Save and Deploy**.

### Docker / Static Web Server (Nginx)

```dockerfile
FROM node:20-alpine AS build
WORKDIR /app
COPY package*.json ./
RUN npm install
COPY . .
RUN npm run build

FROM nginx:alpine
COPY --from=build /app/dist /usr/share/nginx/html
EXPOSE 80
CMD ["nginx", "-g", "daemon off;"]
```

---

## 📄 License

MIT License. ThreeUI components courtesy of Meng To and Design+Code.
